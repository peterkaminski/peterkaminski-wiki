
# GPT-3 Custom Instruction Set

This is an example of a custom GPT instructions. Here, we discuss various aspects related to guidelines and custom instructions.

## Overview

The purpose of this document is to provide a comprehensive overview and serve as a reference.

## Details

- Point 1
- Point 2
- Point 3

For more information, see [[Monthly_Financial_Review.md]] and [[Mindfulness_and_Productivity.md]].
